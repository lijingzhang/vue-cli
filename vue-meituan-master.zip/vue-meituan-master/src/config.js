export default {
  baseURL: 'http://39.108.3.12:3000',  //后端地址
  // baseURL: 'http://127.0.0.1:3000',
  domain: 'http://p3d0ne50u.bkt.clouddn.com/',        //七牛云存储地址
}
